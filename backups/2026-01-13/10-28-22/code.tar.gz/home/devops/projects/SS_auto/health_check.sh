#!/bin/bash
echo "System Health Check"
uptime
df -h
free -m
